class Drink

attr_reader :drink_name, :price

  def initialize(drink_name, price)
    @drink_name = drink_name
    @price = price
  end



end
